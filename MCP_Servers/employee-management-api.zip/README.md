# Employee Management API MCP Server

MCP Server for TC-P0-PY-003 test case - demonstrates complex nested structures (30+ fields) and circular reference detection.

## Test Case Information

- **Test ID**: TC-P0-PY-003
- **Priority**: P0 (Critical)
- **Type**: Integration
- **Focus**: Complex Nested Structures + Circular Reference Detection
- **Agent Style**: react-intrinsic
- **Model**: gpt-oss-120b

## Overview

This MCP server provides tools to interact with the Employee Management API, which demonstrates:
- Complex nested data structures with 30+ fields
- Multiple levels of nesting (personal info, employment, projects, skills, certifications)
- Circular reference detection in organizational hierarchies
- Comprehensive employee profile processing

## Available Tools

### 1. process_employee_data
Process comprehensive employee data with complex nested structures.

**Input**: Complete employee profile with nested objects
```json
{
  "employee": {
    "personal_info": {
      "name": "John Doe",
      "date_of_birth": "1990-05-15",
      "ssn": "123-45-6789",
      "contact": {
        "email": "john.doe@company.com",
        "phone": "+1-555-0100",
        "mobile": "+1-555-0101"
      },
      "address": {
        "street": "123 Tech Street",
        "city": "San Francisco",
        "state": "CA",
        "zipcode": "94105",
        "country": "USA"
      },
      "emergency_contact": {
        "name": "Jane Doe",
        "relationship": "Spouse",
        "phone": "+1-555-0102"
      }
    },
    "employment": {
      "employee_id": "EMP-001",
      "position": "Senior Software Engineer",
      "department": "Engineering",
      "start_date": "2024-01-15",
      "salary": 120000,
      "manager": {
        "employee_id": "EMP-100",
        "name": "Bob Smith"
      },
      "projects": [
        {
          "name": "Cloud Migration",
          "role": "Tech Lead",
          "status": "Active"
        }
      ],
      "skills": [
        {
          "name": "Python",
          "proficiency": "Expert",
          "years_experience": 5
        }
      ],
      "certifications": [
        {
          "name": "AWS Solutions Architect",
          "issuer": "Amazon Web Services",
          "date_obtained": "2023-06-15",
          "expiry_date": "2026-06-15"
        }
      ],
      "performance": {
        "rating": 4.5,
        "last_review_date": "2023-12-01",
        "next_review_date": "2024-06-01"
      }
    }
  }
}
```

### 2. detect_circular_reference
Detect circular references in organizational relationships.

**Input**: Person with nested manager relationships
```json
{
  "person": {
    "name": "Alice Johnson",
    "employee_id": "EMP-001",
    "manager": {
      "name": "Bob Smith",
      "employee_id": "EMP-002",
      "manager": {
        "name": "Alice Johnson",
        "employee_id": "EMP-001"
      }
    }
  }
}
```

## Installation

```bash
cd MCP_Servers/employee-management-api
npm install
npm run build
```

## Usage

### With Claude Desktop

Add to your Claude Desktop configuration:

**MacOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "employee-management-api": {
      "command": "node",
      "args": [
        "/absolute/path/to/MCP_Servers/employee-management-api/build/index.js"
      ]
    }
  }
}
```

### With Cline/Bob

Add to your MCP settings:

```json
{
  "mcpServers": {
    "employee-management-api": {
      "command": "node",
      "args": [
        "/absolute/path/to/MCP_Servers/employee-management-api/build/index.js"
      ]
    }
  }
}
```

## API Endpoints

The tools connect to the deployed API at:
- **Base URL**: `https://complex-tools-openapi.onrender.com/api/v1`
- **Health Check**: `https://complex-tools-openapi.onrender.com/health`

### Endpoints:
- `POST /employees/process` - Process employee data or detect circular references

## Response Format

### Employee Data Response
```json
{
  "type": "employee",
  "employee_name": "John Doe",
  "employee_id": "EMP-001",
  "contact_info": "Email: john.doe@company.com, Phone: +1-555-0100, Mobile: +1-555-0101",
  "address": "123 Tech Street, San Francisco, CA, 94105, USA",
  "emergency_contact": "Jane Doe (Spouse): +1-555-0102",
  "position": "Senior Software Engineer",
  "department": "Engineering",
  "start_date": "2024-01-15",
  "salary": "$120,000",
  "manager": "Bob Smith (EMP-100)",
  "projects": [
    "Cloud Migration - Tech Lead (Active)"
  ],
  "skills": [
    "Python: Expert (5 years)"
  ],
  "certifications": [
    "AWS Solutions Architect (Amazon Web Services) - Obtained: 2023-06-15, Expires: 2026-06-15"
  ],
  "performance": "Rating: 4.5/5, Last Review: 2023-12-01, Next Review: 2024-06-01",
  "summary": "Employee profile for John Doe (EMP-001) - Senior Software Engineer in Engineering"
}
```

### Circular Reference Response
```json
{
  "type": "person",
  "person_name": "Alice Johnson",
  "employee_id": "EMP-001",
  "relationship": "Alice Johnson → Bob Smith → Alice Johnson",
  "relationship_type": "circular",
  "circular_reference_detected": true,
  "message": "Circular reference detected in management chain"
}
```

## Features

### Complex Nested Structures
- **30+ fields** across multiple nesting levels
- Personal information with contact and address details
- Employment data with manager, projects, skills, certifications
- Performance tracking with ratings and review dates

### Circular Reference Detection
- Analyzes organizational hierarchies
- Detects circular reporting relationships
- Prevents infinite loops in org charts
- Provides clear relationship chain visualization

## Testing

Example test scenarios:

1. **Complete Employee Profile**: Process a full employee record with all nested fields
2. **Circular Reference**: Detect when Person A → Person B → Person A
3. **Missing Fields**: Handle partial data gracefully
4. **Invalid Data**: Validate field formats and constraints

## Related Files

- OpenAPI Spec: `../../nested_schemas/tc_p0_py_003/openapi_employee_management.yaml`
- Python Implementation: `../../nested_schemas/tc_p0_py_003/process_complex_data.py`
- Requirements: `../../nested_schemas/tc_p0_py_003/requirements.txt`

## License

MIT