#!/usr/bin/env node

/**
 * Employee Management API MCP Server
 * 
 * This MCP server provides tools for the TC-P0-PY-003 test case,
 * demonstrating complex nested structures (30+ fields) and circular reference detection.
 * 
 * Test Case: TC-P0-PY-003
 * Priority: P0 (Critical)
 * Focus: Complex Nested Structures + Circular Reference Detection
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
    CallToolRequestSchema,
    ListToolsRequestSchema,
    Tool,
} from "@modelcontextprotocol/sdk/types.js";

// API Base URL
const API_BASE_URL = "https://complex-tools-openapi.onrender.com/api/v1";

// Tool definitions
const TOOLS: Tool[] = [
    {
        name: "process_employee_data",
        description: `Process comprehensive employee data with complex nested structures (30+ fields).

This tool handles:
- Personal information (name, DOB, SSN, contact details)
- Address information (street, city, state, zipcode, country)
- Emergency contact details
- Employment information (ID, position, department, dates, salary)
- Manager information
- Project assignments with roles and status
- Skills with proficiency levels and experience
- Certifications with issuers and expiry dates
- Performance ratings and review dates

Use this tool to:
- Process complete employee profiles
- Validate complex nested data structures
- Generate formatted employee summaries
- Track employment history and performance

Example usage: Process a new employee's complete profile including personal info, employment details, skills, certifications, and performance data.`,
        inputSchema: {
            type: "object",
            properties: {
                employee: {
                    type: "object",
                    description: "Complete employee information",
                    properties: {
                        personal_info: {
                            type: "object",
                            description: "Personal information",
                            properties: {
                                name: {
                                    type: "string",
                                    description: "Full name",
                                },
                                date_of_birth: {
                                    type: "string",
                                    description: "Date of birth (YYYY-MM-DD)",
                                },
                                ssn: {
                                    type: "string",
                                    description: "Social Security Number",
                                },
                                contact: {
                                    type: "object",
                                    description: "Contact information",
                                    properties: {
                                        email: {
                                            type: "string",
                                            description: "Email address",
                                        },
                                        phone: {
                                            type: "string",
                                            description: "Phone number",
                                        },
                                        mobile: {
                                            type: "string",
                                            description: "Mobile number",
                                        },
                                    },
                                },
                                address: {
                                    type: "object",
                                    description: "Address information",
                                    properties: {
                                        street: {
                                            type: "string",
                                            description: "Street address",
                                        },
                                        city: {
                                            type: "string",
                                            description: "City",
                                        },
                                        state: {
                                            type: "string",
                                            description: "State",
                                        },
                                        zipcode: {
                                            type: "string",
                                            description: "Zip code",
                                        },
                                        country: {
                                            type: "string",
                                            description: "Country",
                                        },
                                    },
                                },
                                emergency_contact: {
                                    type: "object",
                                    description: "Emergency contact",
                                    properties: {
                                        name: {
                                            type: "string",
                                            description: "Contact name",
                                        },
                                        relationship: {
                                            type: "string",
                                            description: "Relationship",
                                        },
                                        phone: {
                                            type: "string",
                                            description: "Contact phone",
                                        },
                                    },
                                },
                            },
                        },
                        employment: {
                            type: "object",
                            description: "Employment information",
                            properties: {
                                employee_id: {
                                    type: "string",
                                    description: "Employee ID",
                                },
                                position: {
                                    type: "string",
                                    description: "Job position",
                                },
                                department: {
                                    type: "string",
                                    description: "Department",
                                },
                                start_date: {
                                    type: "string",
                                    description: "Start date (YYYY-MM-DD)",
                                },
                                salary: {
                                    type: "number",
                                    description: "Annual salary",
                                },
                                manager: {
                                    type: "object",
                                    description: "Manager information",
                                    properties: {
                                        employee_id: {
                                            type: "string",
                                            description: "Manager's employee ID",
                                        },
                                        name: {
                                            type: "string",
                                            description: "Manager's name",
                                        },
                                    },
                                },
                                projects: {
                                    type: "array",
                                    description: "Project assignments",
                                    items: {
                                        type: "object",
                                        properties: {
                                            name: {
                                                type: "string",
                                                description: "Project name",
                                            },
                                            role: {
                                                type: "string",
                                                description: "Role in project",
                                            },
                                            status: {
                                                type: "string",
                                                description: "Project status",
                                                enum: ["Active", "Completed", "On Hold"],
                                            },
                                        },
                                    },
                                },
                                skills: {
                                    type: "array",
                                    description: "Skills and proficiency",
                                    items: {
                                        type: "object",
                                        properties: {
                                            name: {
                                                type: "string",
                                                description: "Skill name",
                                            },
                                            proficiency: {
                                                type: "string",
                                                description: "Proficiency level",
                                                enum: ["Beginner", "Intermediate", "Advanced", "Expert"],
                                            },
                                            years_experience: {
                                                type: "integer",
                                                description: "Years of experience",
                                            },
                                        },
                                    },
                                },
                                certifications: {
                                    type: "array",
                                    description: "Professional certifications",
                                    items: {
                                        type: "object",
                                        properties: {
                                            name: {
                                                type: "string",
                                                description: "Certification name",
                                            },
                                            issuer: {
                                                type: "string",
                                                description: "Issuing organization",
                                            },
                                            date_obtained: {
                                                type: "string",
                                                description: "Date obtained (YYYY-MM-DD)",
                                            },
                                            expiry_date: {
                                                type: "string",
                                                description: "Expiry date (YYYY-MM-DD)",
                                            },
                                        },
                                    },
                                },
                                performance: {
                                    type: "object",
                                    description: "Performance information",
                                    properties: {
                                        rating: {
                                            type: "number",
                                            description: "Performance rating (0-5)",
                                            minimum: 0,
                                            maximum: 5,
                                        },
                                        last_review_date: {
                                            type: "string",
                                            description: "Last review date (YYYY-MM-DD)",
                                        },
                                        next_review_date: {
                                            type: "string",
                                            description: "Next review date (YYYY-MM-DD)",
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        },
    },
    {
        name: "detect_circular_reference",
        description: `Detect circular references in organizational relationships.

This tool analyzes person-manager relationships to identify circular references where:
- Person A reports to Person B
- Person B reports to Person C
- Person C reports back to Person A (circular)

Use this tool to:
- Validate organizational hierarchies
- Detect circular reporting structures
- Identify relationship chains
- Prevent infinite loops in org charts

Example usage: Check if there's a circular reference in the management chain where Alice reports to Bob, Bob reports to Charlie, and Charlie reports back to Alice.`,
        inputSchema: {
            type: "object",
            properties: {
                person: {
                    type: "object",
                    description: "Person with potential circular manager reference",
                    properties: {
                        name: {
                            type: "string",
                            description: "Person's name",
                        },
                        employee_id: {
                            type: "string",
                            description: "Employee ID",
                        },
                        manager: {
                            type: "object",
                            description: "Manager information (can be nested)",
                            properties: {
                                name: {
                                    type: "string",
                                    description: "Manager's name",
                                },
                                employee_id: {
                                    type: "string",
                                    description: "Manager's employee ID",
                                },
                                manager: {
                                    type: "object",
                                    description: "Manager's manager (recursive)",
                                    properties: {
                                        name: {
                                            type: "string",
                                            description: "Name",
                                        },
                                        employee_id: {
                                            type: "string",
                                            description: "Employee ID",
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
        },
    },
];

// Helper function to make API calls
async function callAPI(endpoint: string, data: any): Promise<any> {
    const url = `${API_BASE_URL}${endpoint}`;

    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                `API error (${response.status}): ${result.error || result.message || "Unknown error"}`
            );
        }

        return result;
    } catch (error) {
        if (error instanceof Error) {
            throw new Error(`Failed to call API: ${error.message}`);
        }
        throw error;
    }
}

// Create server instance
const server = new Server(
    {
        name: "employee-management-api",
        version: "1.0.0",
    },
    {
        capabilities: {
            tools: {},
        },
    }
);

// List available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
    return {
        tools: TOOLS,
    };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;

    try {
        switch (name) {
            case "process_employee_data": {
                const result = await callAPI("/employees/process", args);
                return {
                    content: [
                        {
                            type: "text",
                            text: JSON.stringify(result, null, 2),
                        },
                    ],
                };
            }

            case "detect_circular_reference": {
                const result = await callAPI("/employees/process", args);
                return {
                    content: [
                        {
                            type: "text",
                            text: JSON.stringify(result, null, 2),
                        },
                    ],
                };
            }

            default:
                throw new Error(`Unknown tool: ${name}`);
        }
    } catch (error) {
        if (error instanceof Error) {
            return {
                content: [
                    {
                        type: "text",
                        text: `Error: ${error.message}`,
                    },
                ],
                isError: true,
            };
        }
        throw error;
    }
});

// Start the server
async function main() {
    const transport = new StdioServerTransport();
    await server.connect(transport);
    console.error("Employee Management API MCP Server running on stdio");
}

main().catch((error) => {
    console.error("Fatal error in main():", error);
    process.exit(1);
});

// Made with Bob